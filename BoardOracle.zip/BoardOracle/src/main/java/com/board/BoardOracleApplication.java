package com.board;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BoardOracleApplication {

	public static void main(String[] args) {
		SpringApplication.run(BoardOracleApplication.class, args);
	}

}
